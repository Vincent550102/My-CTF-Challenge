mongo_username = "root"
mongo_password = "oihuygh32rei"
flag = "CGGC{fakeflag}"
