mongo_username = "root"
mongo_password = "oihuygh32rei"
flag = "CGGC{nosql_injection_with_mongodb_is_fun}"
